from env import Env
from board1 import Board

env = Env()
# observation, reward, done, _ = env.step(40)
# env.render()
# a = 1

env.board.move1(5, 7, 2)
env.board.move1(7, 5, 2)
env.board.move1(6, 6, 2)
env.board.move1(8, 4, 2)
v1 = env.get_reward()
v2 = env.get_reward()
a = 1
